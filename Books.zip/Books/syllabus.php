

<?php 
include('header.php');
?>
       

					    <form action="insert_syllabus.php" method="post" >
					    <div class="form-group">
					    <label >Syllabus:</label><br>
					    <input type="text" name="syllabus_name" class="form-control"   placeholder="syllabus" ><br>					  
					  <button type="submit" class="btn btn-primary" value="submit">Submit</button>
					</form>



<?php 
include('footer.php');
?>
    		
    		

    	








	
	


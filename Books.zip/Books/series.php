

<?php 
include('header.php');
?>
       

					    <form action="insert_series.php" method="post" >
					    <div class="form-group">
					    <label >Series:</label><br>
					    <input type="text" name="series_name" class="form-control"   placeholder="Series" ><br>					  
					  <button type="submit" class="btn btn-primary" value="submit">Submit</button>
					</form>



<?php 
include('footer.php');
?>
    		
    		

    	








	
	


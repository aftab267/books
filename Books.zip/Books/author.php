

<?php 
include('header.php');
?>
       
						
					<br>
					<br>
					<div class="col-md-6">
					    <form action="insert_author.php" method="post" >
					    <div class="form-group">
					    <label >Author:</label><br>
					    <input type="text" name="author_name" class="form-control"   placeholder="Author" ><br>					  
					  <button type="submit" class="btn btn-primary" value="submit">Submit</button>
					</form>
				</div>
					<br>
					<br>

					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>


<?php 
include('footer.php');
?>
    		
    		

    	








	
	

